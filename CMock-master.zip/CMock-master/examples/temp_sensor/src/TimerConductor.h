#ifndef _TIMERCONDUCTOR_H
#define _TIMERCONDUCTOR_H

#include "Types.h"

void TimerConductor_Init(void);
void TimerConductor_Run(void);

#endif // _TIMERCONDUCTOR_H
